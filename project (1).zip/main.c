#include <stdio.h>
#include "pico/stdlib.h"

int main() {
  stdio_init_all();
  gpio_init (1);
  gpio_set_dir (1,false);
  gpio_init (25);
  gpio_set_dir (25,true);
  char a = gpio_get (1);
  char b = gpio_get (25);
  while (true) {
    if (a==1)
    {
      if (b==true)
      {
        gpio_put (25,false);
        sleep_ms (500);
      }
      if (b==false);
      {
      gpio_put (25,true);
      sleep_ms (500);
      }
      
    }
    else if (a==0)
    {

    }
}